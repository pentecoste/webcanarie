# static
Cartella per tutti i contenuti statici serviti dal server (es. file HTML puri, CSS, immagini, script JS).
